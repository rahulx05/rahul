


const Order = require("../models/orderModel");
const Product = require("../models/productModel");

exports.newOrder = async (req,res)=>{
    const {shippingInfo,slot,totalprice,phoneNo,paymentInfo,orderServices}=req.body;

    const userId = req.user.id;

    try {

        const order = await Order.create({
            shippingInfo,slot,totalprice,phoneNo,paymentInfo,orderServices,user:userId
        })
        res.status(200).json({
			success: true,
			order,
			message: "New product created",
			
		});


        
    } catch (error) {

        console.error(error);
		res.status(500).json({
			success: false,
			message: "Failed to create product",
			error: error.message,
		});
        
    }

}


exports.updateOrder = async (req,res)=>{
    try {

        const {orderId} = req.body;
        // console.log("mmmmmmmmmmmmm",orderId);


        const order = await Order.findById({_id:orderId});
        // console.log("nnnnnnnnn",order);

        if(order.orderStatus==="Done"){
            res.status(500).json({
                success: false,
                message: "Already Done",
                error: error.message,
            });
        }
        order.orderStatus = req.body.status;
        if(req.body.status === "Delivered"){
            order.deliveredAt = Date.now();

        }
        await order.save({validateBeforeSave:false});
        res.status(200).json({
            success: true,
            order
            
          });
        
    } catch (error) {
        console.error(error);
		res.status(500).json({
			success: false,
			message: "Failed to update product",
			error: error.message,
		});
    }
}


exports.myOrders = async (req,res)=>{
    try {
        const orders = await Order.find({ user: req.user.id });

        res.status(200).json({
            success: true,
            orders
        });
        
    } catch (error) {
        console.error(error);
		res.status(500).json({
			success: false,
			message: "Failed to my order",
			error: error.message,
		});
    }
}
