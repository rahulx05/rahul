
const { uploadImageToCloudinary } = require("../utils/imageUploader");


const Product = require("../models/productModel")

// exports.createProduct = async (req,res)=>{
//     try{
//         const {name,description,price,category,images} = req.body;
//         if (
// 			!name ||
// 			!description ||
// 			!price ||
// 			!category||
// 			!images
// 		) {
// 			return res.status(400).json({
// 				success: false,
// 				message: "All Fields are Mandatory",
// 			});
// 		}

		

// 		// console.log("lllllll",req.body)

		
        
//         const newProduct  = await Product.create({
// 			name,description,price,category,images
// 		})

//         console.log("pppppp",newProduct);

//         res.status(200).json({
// 			success: true,
// 			newProduct,
// 			message: "New product created",
			
// 		});


//     }
//     catch(error){
//         console.error(error);
// 		res.status(500).json({
// 			success: false,
// 			message: "Failed to create product",
// 			error: error.message,
// 		});
//     }
// }

exports.createProduct = async (req,res)=>{
    try{
        const {name,description,price,category,images} = req.body;
		const thumbnail = req.files.thumbnailImage;
        if (
			!name ||
			!description ||
			!price ||
			!category||
			!thumbnail
		) {
			return res.status(400).json({
				success: false,
				message: "All Fields are Mandatory",
			});
		}

		

		// console.log("lllllll",req.body)
		const thumbnailImage = await uploadImageToCloudinary(
			thumbnail,
			process.env.FOLDER_NAME
		);
		console.log(thumbnailImage);
		
        
        const newProduct  = await Product.create({
			name,description,price,category,thumbnail:thumbnailImage.secure_url
		})

        console.log("pppppp",newProduct);

        res.status(200).json({
			success: true,
			newProduct,
			message: "New product created",
			
		});


    }
    catch(error){
        console.error(error);
		res.status(500).json({
			success: false,
			message: "Failed to create product",
			error: error.message,
		});
    }
}

exports.getProductDetails = async (req,res)=>{
	try {
		console.log("huiiiii",req.user);
		const product = await Product.findById(req.params.id);
		if(!product){
			res.status(404).json({
				success: false,
				message: "product not found",
				error: error.message,
			});
			
		}
		res.status(200).json({
			success:true,
			message:"product found",product
		})

		
	} catch (error) {
		console.error(error);
		res.status(500).json({
			success: false,
			message: "issue in get product details",
			error: error.message,
		});
	}
}



exports.allProducts =async (req,res)=>{
	try {
		const product = await Product.find();
		
		res.status(200).json({
			success:true,
			message:"product found",product
		})

	} catch (error) {
		console.error(error);
		res.status(500).json({
			success: false,
			message: "issue in get product all",
			error: error.message,
		});
		
	}
}
