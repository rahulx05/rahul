const RatingAndReview = require("../models/RatingAndReview");
const Product = require("../models/productModel");
const { default: mongoose } = require("mongoose");

exports.createRating = async (req, res) => {
  try {
    const userId = req.user.id;

    const { rating, review, productId } = req.body;

    const alreadyReviewed = await RatingAndReview.findOne({
      user: userId,
      product: productId,
    });
    if (alreadyReviewed) {
      return res
        .status(404)
        .json({ success: false, message: "Already reviewed" });
    }
    const ratingReview = await RatingAndReview.create({
      rating,
      review,
      product: productId,
      user: userId,
    });

    await Product.findByIdAndUpdate(
      { _id: productId },
      {
        $push: {
          ratingAndReviews: ratingReview._id,
        },
      }
    );

    res.status(200).json({
      success: true,
      message: "Rating added successfully",
      ratingReview,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};

exports.getAverageRating = async (req,res)=>{
    try {
        const productId =req.body.productId;
        const result = await RatingAndReview.aggregate([
            {
                $match:{
                    product:new mongoose.Types.ObjectId(productId),
                }
            },
            {
                $group:{
                    _id:null,
                    averageRating:{$avg:"$rating"}
                }
            }
        ])
        if(result.length > 0) {
            return res.status(200).json({averageRating: result[0].averageRating});
        }
        else{
            return res.status(200).json({message: "Average rating is 0",
        averageRating:0});
        }
        
    } catch (error) {
        console.log(error);
        res.status(500).json({message: error.message});
    }
}