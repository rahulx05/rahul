
const mongoose = require("mongoose");
const productSchema = mongoose.Schema({
    name:{
        type:String,
        required:true,
       
    },
    description:{
        type:String,
        required:true
    },
    price:{
        type:Number,
        required:true,
        maxLength:8
    },
    thumbnail: {
		type: String,
	},
    
    // images:[{
    //     public_id:{
    //         type:String,
    //         required:true
    //     },
        
    //     url:{
    //         type:String,
    //         required:true
    //     },
    // }],
    category:{
        type:String,
        require:true,
        
    },
    ratingAndReviews: [
		{
			type: mongoose.Schema.Types.ObjectId,
			ref: "RatingAndReview",
		},
	],
    
    createdAt:{
        type:Date,
        default:Date.now
        
    },
    user:{
        type: mongoose.Schema.ObjectId,
        ref: "User",
        default:"658f90023fd4f9f5ee3c0e7b",
        required: true,
    }
    


})



module.exports = mongoose.model("Product",productSchema);
