

const express = require("express");
const router = express.Router();


const {isDemo}=require("../middlewares/demo");

const { auth,isAdmin } = require("../middlewares/auth")

const {newOrder}= require("../controllers/orderController");
const {updateOrder,myOrders} = require("../controllers/orderController");


router.post("/neworder",auth,newOrder);
router.put("/updateOrder",auth,isAdmin,updateOrder);
router.get("/myOrder",auth,myOrders)
module.exports = router;