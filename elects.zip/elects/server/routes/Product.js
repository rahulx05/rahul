const express = require("express")
const router = express.Router()

const {createProduct} = require("../controllers/productController");
const {getProductDetails,allProducts} = require("../controllers/productController")
const {createRating} = require("../controllers/RatingAndReviews");
const {getAverageRating} = require("../controllers/RatingAndReviews");



const {isDemo}=require("../middlewares/demo");

const { auth,isAdmin } = require("../middlewares/auth")


router.post("/newProduct",createProduct)
router.get("/productget/:id",getProductDetails);
router.post("/createrating",auth,createRating);
router.get("/getAverageRating", getAverageRating);
router.get("/allProducts",allProducts)
// router.post("/neworder",auth,newOrder)

module.exports = router;