// import logo from './logo.svg';
import './App.css';
import Header from './Components/common/Header';
import OpenRoute from './Components/auth/OpenRoute';
import {Route,Routes} from "react-router-dom"
import Login from './Components/auth/Login';
import Home from "./Components/common/Home"
import Signup from "./Components/auth/Signup";
import VerifyOtp from './Components/auth/VerifyOtp';
import ProductsPage from './Components/core/working/ProductsPage';
// import CartComponent from './Components/core/cart/CartComponent';
import CartComponent from './Components/core/cart/CartComponent';
import CurrentLocation from './Components/core/Location/CurrentLocation';

function App() {
  return (
    <div className=" bg-white flex flex-col w-screen min-h-screen">
      
      <Header  />
     
      
      <Routes>

        <Route path="/" element={<Home />}/>

        <Route path="/login" element={<OpenRoute><Login/></OpenRoute>}/>

        <Route path="/signup" element={<OpenRoute><Signup/></OpenRoute>}/>

        <Route path="/verify-email" element={<VerifyOtp />} />

        <Route path="/products" element={<ProductsPage />} />

        <Route path="/cart" element={<CartComponent />} />

        <Route path="/location" element={<CurrentLocation />} />


      </Routes>


    </div>
  );
}

export default App;
