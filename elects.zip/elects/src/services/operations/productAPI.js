import { endpoints } from "../apis"
import {apiConnector} from "../apiconnector"
import { toast } from "react-hot-toast"

import { setLoading} from "../../slices/authSlice"
import {setProgress} from "../../slices/loadingBarSlice"

const {ALL_PRODUCTS_API } = endpoints;



export const getAllProducts = async (dispatch) => {
    const toastId = toast.loading("Loading...")
    let result = []
    // dispatch(setLoading(true));
    dispatch(setProgress(50));

    
    try {
      const response = await apiConnector("GET", ALL_PRODUCTS_API)
      // console.log("all products",response)
      if (!response?.data?.success) {
        dispatch(setLoading(false));
        throw new Error("Could Not Fetch Course Categories")
      }
      result = response?.data?.product
    } catch (error) {
      console.log("GET_ALL_COURSE_API API ERROR............", error)
      toast.error(error.message)
    }
    toast.dismiss(toastId)
    // dispatch(setLoading(false));
    dispatch(setProgress(100));


    // console.log("result",result)
    
    return result
  }



