
import React from 'react';
import {
  Flex,
  Heading,
  Input,
  Button,
  FormControl,
  FormLabel,
  Switch,
  useColorMode,
  useColorModeValue,
} from '@chakra-ui/react';
import { useState } from 'react';
import { useDispatch } from "react-redux"
import { Link, useNavigate } from "react-router-dom"

import { login } from "../../services/operations/authAPI"
import { setProgress } from "../../slices/loadingBarSlice"

// import { useState } from 'react';
import { toast } from "react-hot-toast"
import { sendOtp } from '../../services/operations/authAPI';
import { setSignupData } from '../../slices/authSlice';
// import { setProgress } from '../../slices/loadingBarSlice';


const Signup = () => {
    const formBackground = useColorModeValue('gray.100', 'gray.700');
    const [accountType, setAccountType] = useState("Customer")
    const navigate = useNavigate()
  const dispatch = useDispatch()

  // const { email, password } = formData

  // const handleOnChange = (e) => {
  //   setFormData((prevData) => ({
  //     ...prevData,
  //     [e.target.name]: e.target.value,
  //   }))
  // }


  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
  })

  const { firstName, lastName, email, password, confirmPassword } = formData


  const handleOnChange = (e) => {
    setFormData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value,
    }))
  }


  const handleOnSubmit = (e) => {
    e.preventDefault()

    if (password !== confirmPassword) {
      toast.error("Passwords Do Not Match")
      return
    }
    const signupData = {
      ...formData,
      accountType
      
    }

    // Setting signup data to state
    // To be used after otp verification
    dispatch(setSignupData(signupData))
    // Send OTP to user for verification
    dispatch(sendOtp(formData.email, navigate))

    // Reset
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      confirmPassword: "",
    })
    
  }

  return (
    <div className=''>
        <Flex h="70vh" alignItems="center" justifyContent="center" className='mx-auto flex w-11/12'>
      <Flex
        flexDirection="column"
        bg={formBackground}
        p={12}
        borderRadius={8}
        boxShadow="lg"
      >
        <Heading mb={6}>Sign Up</Heading>

        <div className='flex w-11/12'>
        <Input
          placeholder="firstName"
          type="text"
          variant="filled"
          mb={3}
          value={firstName}
          required
          name='firstName'
          onChange={handleOnChange}
          
        
        />
        <Input
         
          variant="filled"
          mb={3}
          required
              type="text"
              name="lastName"
              value={lastName}
              onChange={handleOnChange}
              placeholder="Last name"
          

          

        />
        </div>


        <Input
            required
            type="text"
            name="email"
            value={email}
            onChange={handleOnChange}
            placeholder="Enter email address"
         
          variant="filled"
          mb={3}
          

          

        />
        <Input
        required
          placeholder="Password"
          type="password"
          variant="filled"
          mb={3}
          name="password"
          onChange={handleOnChange}
          value={password}

          

          

        />
        
        <Input
        required
          placeholder="Confirm Password"
          type="password"
          variant="filled"
          name="confirmPassword"
              value={confirmPassword}
          mb={6}
          onChange={handleOnChange}
         
        />



        
        <Button colorScheme="teal" mb={8} onClick={handleOnSubmit} >
          Sgn Up
        </Button>
        <FormControl display="flex" alignItems="center">
          <FormLabel htmlFor="dark_mode" mb="0">
            Enable Dark Mode?
          </FormLabel>
          
        </FormControl>
      </Flex>
      
    </Flex>

    </div>
    
  );
};

export default Signup;
