// import React from 'react';
// import {
//   Flex,
//   Heading,
//   Input,
//   Button,
//   FormControl,
//   FormLabel,
//   Switch,
//   useColorMode,
//   useColorModeValue,
// } from '@chakra-ui/react';
// import { useState } from 'react';
// import { useDispatch } from "react-redux"
// import { Link, useNavigate } from "react-router-dom"

// import { login } from "../../services/operations/authAPI"
// import { setProgress } from "../../slices/loadingBarSlice"


// const Login = () => {
//   const { toggleColorMode } = useColorMode();
//   const formBackground = useColorModeValue('gray.100', 'gray.700');

//   const navigate = useNavigate()
//   const dispatch = useDispatch()
//   const [email,setEmail]= useState("");
//   const [pass,setPass] = useState("")

//   // const [showPassword, setShowPassword] = useState(false)

//   // const { email, password } = formData

//   // const handleOnChange = (e) => {
//   //   setFormData((prevData) => ({
//   //     ...prevData,
//   //     [e.target.name]: e.target.value,
//   //   }))
//   // }

//   // const handleOnSubmit = (e) => {
//   //   e.preventDefault()
//   //   dispatch(login(email, password, navigate))
//   // }



//   return (
//     <Flex h="85vh" alignItems="center" justifyContent="center">
//       <Flex
//         flexDirection="column"
//         bg={formBackground}
//         p={12}
//         borderRadius={8}
//         boxShadow="lg"
//       >
//         <Heading mb={6}>Log In</Heading>
//         <Input
//           placeholder="johndoe@gmail.com"
//           type="email"
//           variant="filled"
//           mb={3}
          

//         />
//         <Input
//           placeholder="**********"
//           type="password"
//           variant="filled"
//           mb={6}
//         />
//         <Button colorScheme="teal" mb={8}>
//           Log In
//         </Button>
//         <FormControl display="flex" alignItems="center">
//           <FormLabel htmlFor="dark_mode" mb="0">
//             Enable Dark Mode?
//           </FormLabel>
          
//         </FormControl>
//       </Flex>
//     </Flex>
//   );
// };

// export default Login;

import React from 'react';
import {
  Flex,
  Heading,
  Input,
  Button,
  FormControl,
  FormLabel,
  Switch,
  useColorMode,
  useColorModeValue,
} from '@chakra-ui/react';
import { useState } from 'react';
import { useDispatch } from "react-redux"
import { Link, useNavigate } from "react-router-dom"

import { login } from "../../services/operations/authAPI"
import { setProgress } from "../../slices/loadingBarSlice"


const Login = () => {
  const { toggleColorMode } = useColorMode();
  const formBackground = useColorModeValue('gray.100', 'gray.700');

  const navigate = useNavigate()
  const dispatch = useDispatch()
  const [email,setEmail]= useState("");
  const [password,setPassword] = useState("")

  // const [showPassword, setShowPassword] = useState(false)

  // const { email, password } = formData

  // const handleOnChange = (e) => {
  //   setFormData((prevData) => ({
  //     ...prevData,
  //     [e.target.name]: e.target.value,
  //   }))
  // }

    const handleOnChangeEmail=(e)=>{
      setEmail(e.target.value);
      
    }
    const handleOnChangePass=(e)=>{
      setPassword(e.target.value);
      
    }

  const handleOnSubmit = (e) => {
    console.log("huoooooooooooooooooooooooooooooooooo");

    // e.preventDefault()
    dispatch(login(email, password, navigate))
  }



  return (
    <Flex h="70vh" alignItems="center" justifyContent="center" >
      <Flex
        flexDirection="column"
        bg={formBackground}
        p={12}
        borderRadius={8}
        boxShadow="lg"
      >
        <Heading mb={6}>Log In</Heading>
        <Input
          placeholder="johndoe@gmail.com"
          type="email"
          variant="filled"
          mb={3}
          value={email}
          onChange={handleOnChangeEmail}

          

        />
        <Input
          placeholder="**********"
          type="password"
          variant="filled"
          mb={6}
          value={password}
          onChange={handleOnChangePass}
        />
        <Button colorScheme="teal" mb={8} onClick={()=>{handleOnSubmit()}}>
          Log In
        </Button>
        <FormControl display="flex" alignItems="center">
          <FormLabel htmlFor="dark_mode" mb="0">
            Enable Dark Mode?
          </FormLabel>
          
        </FormControl>
      </Flex>
      
    </Flex>
  );
};

export default Login;
