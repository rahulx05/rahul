// import React from "react";
// import { Link, Box, Flex, Text, Button, Stack } from "@chakra-ui/react";
// import { useDispatch } from "react-redux";
// import { useSelector } from 'react-redux'
// import { ReactComponent as Logo } from "../../assets/Logo/crown.svg";

// const NavBar = (props) => {
//   const [isOpen, setIsOpen] = React.useState(false);

//   const toggle = () => setIsOpen(!isOpen);

//   return (
//     <NavBarContainer {...props}  className="mb-0">
//       <Logo />
//       <MenuToggle toggle={toggle} isOpen={isOpen} />
//       <MenuLinks isOpen={isOpen} />
//     </NavBarContainer>
//   );
// };

// const CloseIcon = () => (
//   <svg width="24" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
//     <title>Close</title>
//     <path
//       fill="white"
//       d="M9.00023 7.58599L13.9502 2.63599L15.3642 4.04999L10.4142 8.99999L15.3642 13.95L13.9502 15.364L9.00023 10.414L4.05023 15.364L2.63623 13.95L7.58623 8.99999L2.63623 4.04999L4.05023 2.63599L9.00023 7.58599Z"
//     />
//   </svg>
// );

// const MenuIcon = () => (
//   <svg
//     width="24px"
//     viewBox="0 0 20 20"
//     xmlns="http://www.w3.org/2000/svg"
//     fill="white"
//   >
//     <title>Menu</title>
//     <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z" />
//   </svg>
// );

// const MenuToggle = ({ toggle, isOpen }) => {
//   return (
//     <Box display={{ base: "block", md: "none" }} onClick={toggle}>
//       {isOpen ? <CloseIcon /> : <MenuIcon />}
//     </Box>
//   );
// };

// const MenuItem = ({ children, isLast, to = "/", ...rest }) => {
//   return (
//     <Link href={to}>
//       <Text display="block" {...rest}>
//         {children}
//       </Text>
//     </Link>
//   );
// };

// const MenuLinks = ({ isOpen }) => {
//   const dispatch=useDispatch();

//     const {token}=useSelector(state=>state.auth);
//     // const {user}=useSelectsor(state=>state.profile);
//   return (
//     <Box
//       display={{ base: isOpen ? "block" : "none", md: "block" }}
//       flexBasis={{ base: "100%", md: "auto" }}
//     >
//       <Stack
//         spacing={8}
//         align="center"
//         justify={["center", "space-between", "flex-end", "flex-end"]}
//         direction={["column", "row", "row", "row"]}
//         pt={[4, 4, 0, 0]}
//       >
//         <MenuItem to="/">Minha Conta</MenuItem>
//         <MenuItem to="/how"> Meus Pedidos </MenuItem>
//         <MenuItem to="/faetures"> Favoritos </MenuItem>

//         {
//                     token ==null && (
//                       <MenuItem to="/login" >
//                       <Button
//                         size="sm"
//                         rounded="md"
//                         bg={["primary.500", "primary.500", "white", "white"]}
//                         color={["white", "white", "primary.500", "primary.500"]}
//                         _hover={{
//                           bg: ["primary.100", "primary.100","primary.100", "primary.100", ]
//                         }}
//                       >
//                         Login
//                       </Button>
//                     </MenuItem>
//                     )
//                 }
//                 {
//                     token ==null && (
//                       <MenuItem to="/signup" isLast>
//                       <Button
//                         size="sm"
//                         rounded="md"
//                         color={["primary.500", "primary.500", "white", "white"]}
//                         bg={["white", "white", "primary.500", "primary.500"]}
//                         _hover={{
//                           bg: ["primary.100", "primary.100", "primary.600", "primary.600"]
//                         }}
//                       >
//                         Sign Up
//                       </Button>
//                     </MenuItem>
//                     )
//                 }

//       </Stack>
//     </Box>
//   );
// };

// const NavBarContainer = ({ children, ...props }) => {
//   return (
//     <Flex
//       as="nav"
//       align="center"
//       justify="space-between"
//       wrap="wrap"
//       w="100%"
//       mb={8}
//       p={8}
//       bg={["primary.500", "primary.500", "transparent", "transparent"]}
//       color={["white", "white", "primary.700", "primary.700"]}
//       {...props}
//     >
//       {children}
//     </Flex>
//   );
// };

// export default NavBar;

import React, { useState } from "react";
import { Box, Link, Text, Stack, Flex, Icon, Button } from "@chakra-ui/react";
import { MdClose, MdMenu } from "react-icons/md";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { logout } from "../../services/operations/authAPI";


const Header = () => {
  return (
    <>
      <header
    class="fixed inset-x-0 top-0 z-30 mx-auto w-full max-w-screen-md border border-gray-100 bg-white/80 py-3 shadow backdrop-blur-lg md:top-6 md:rounded-3xl lg:max-w-screen-lg">
    <div class="px-4">
        <div class="flex items-center justify-between">
            <div class="flex shrink-0">
                <a aria-current="page" class="flex items-center" href="/">
                    <img class="h-7 w-auto" src="https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg" alt="" />
                    <p class="sr-only">Website Title</p>
                </a>
            </div>
            <div class="hidden md:flex md:items-center md:justify-center md:gap-5">
                <a aria-current="page"
                    class="inline-block rounded-lg px-2 py-1 text-sm font-medium text-gray-900 transition-all duration-200 hover:bg-gray-100 hover:text-gray-900"
                    href="#">How it works</a>
                <a class="inline-block rounded-lg px-2 py-1 text-sm font-medium text-gray-900 transition-all duration-200 hover:bg-gray-100 hover:text-gray-900"
                    href="#">Pricing</a>
            </div>
            <div class="flex items-center justify-end gap-3">
                <a class="hidden items-center justify-center rounded-xl bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 transition-all duration-150 hover:bg-gray-50 sm:inline-flex"
                    href="/login">Sign in</a>
                <a class="inline-flex items-center justify-center rounded-xl bg-blue-600 px-3 py-2 text-sm font-semibold text-white shadow-sm transition-all duration-150 hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
                    href="/login">Login</a>
            </div>
        </div>
    </div>
</header>
    </>
    
  )
}

export default Header